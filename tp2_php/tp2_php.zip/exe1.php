<html>
<body>

<form action="exe1-2.php" method="post">
  <label for="name">Nom:</label>
  <input type="text" id="name" name="name" placeholder="Enter your name"><br>
  <label for="password">mot de passe:</label>
  <input type="password" id="password" name="password" placeholder="Enter your password"><br>
  <label>sexe:</label><br>
  <input type="radio" id="male" name="gender" value="male">
  <label for="male">homme</label><br>
  <input type="radio" id="female" name="gender" value="female">
  <label for="female">Femme</label><br>
  <input type="submit" value="Validate">
</form>

</body>
</html>
